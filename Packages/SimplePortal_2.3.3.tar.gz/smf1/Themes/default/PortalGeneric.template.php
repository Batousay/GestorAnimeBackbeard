<?php
// Version: 2.3.2; PortalGeneric

function sp_template_inline_permissions()
{
	global $context, $settings, $options, $txt;

	echo '
		<fieldset id="permissions">
			<legend><a href="javascript:void(0);" onclick="document.getElementById(\'permissions\').style.display = \'none\';document.getElementById(\'permissions_link\').style.display = \'block\'; return false;">', $txt['avatar_select_permission'], '</a></legend>';
		echo '
			<table width="100%" border="0">';
	foreach ($context['member_groups'] as $group)
	{
		echo '
				<tr>
					<td align="center"><input type="checkbox" name="member_groups[]" value="', $group['id'], '"', !empty($group['checked']) ? ' checked="checked"' : '', ' class="check" /></td>
					<td><span', $group['is_post_group'] ? ' style="border-bottom: 1px dotted;" title="' . $txt['mboards_groups_post_group'] . '"' : '', '>', $group['name'], '</span></td>
				</tr>';
	}
	echo '
				<tr>
					<td colspan="2">
						<i>', $txt[737], '</i> <input type="checkbox" onclick="invertAll(this, this.form, \'member_groups[]\');" />
					</td>
				</tr>
			</table>
		</fieldset>

		<a href="javascript:void(0);" onclick="document.getElementById(\'permissions\').style.display = \'block\'; document.getElementById(\'permissions_link\').style.display = \'none\'; return false;" id="permissions_link" style="display: none;">[ ', $txt['avatar_select_permission'], ' ]</a>

		<script language="JavaScript" type="text/javascript"><!-- // --><' . '!' . '[' . 'CDATA' . '[
			document.getElementById("permissions").style.display = "none";
			document.getElementById("permissions_link").style.display = "";
		// ' . ']' . ']' . '></script>';
}

?>