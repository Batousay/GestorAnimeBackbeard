<?php
// Version: 2.3.2; PortalAdminShoutbox

function template_shoutbox_list()
{
	global $context, $settings, $options, $scripturl, $txt, $modSettings;

	echo '
	<form action="', $scripturl, '?action=manageportal;area=portalshoutbox;sa=list" method="post" accept-charset="', $context['character_set'], '" onsubmit="return confirm(\'', $txt['sp_shoutbox_remove_confirm'], '\');">
		<table cellspacing="1" cellpadding="4" class="sp_fullwidth sp_auto_align bordercolor">
			<tr class="catbg3">
				<td colspan="', count($context['columns']) + 1, '"><strong>', $txt[139], ':</strong> ', $context['page_index'], '</td>
			</tr>
			<tr class="titlebg">';

	foreach ($context['columns'] as $column)
	{
		if ($column['selected'])
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					<a href="', $column['href'], '">', $column['label'], '&nbsp;<img src="', $settings['images_url'], '/sort_', $context['sort_direction'], '.gif" alt="" /></a>
				</th>';
		elseif ($column['sortable'])
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					', $column['link'], '
				</th>';
		else
			echo '
				<th', isset($column['width']) ? ' width="' . $column['width'] . '"' : '', '>
					', $column['label'], '
				</th>';
	}

	echo '
				<th><input type="checkbox" class="check" onclick="invertAll(this, this.form);" /></th>
			</tr>';
	
	if (empty($context['shoutboxes']))
		echo '
			<tr>
				<td colspan="', count($context['columns']) + 1, '" class="sp_center windowbg">', $txt['sp_error_no_shoutbox'], '</td>
			</tr>';

	foreach ($context['shoutboxes'] as $shoutbox)
	{
		echo '
			<tr>
				<td class="sp_left windowbg">', $shoutbox['name'], '</td>
				<td class="sp_center windowbg">', $shoutbox['shouts'], '</td>
				<td class="sp_center windowbg">', $shoutbox['caching'] ? $txt['sp_yes'] : $txt['sp_no'], '</td>
				<td class="sp_center windowbg">', $shoutbox['status_image'], '</td>
				<td class="sp_center windowbg">', implode('&nbsp;', $shoutbox['actions']), '</td>
				<td class="sp_center windowbg2"><input type="checkbox" name="remove[]" value="', $shoutbox['id'], '" class="check" /></td>
			</tr>';
	}

	echo '
			<tr class="catbg3">
				<td colspan="', count($context['columns']) + 1, '" class="sp_left">
					<div class="sp_float_right">
						<input type="submit" name="remove_shoutbox" value="', $txt['sp_admin_shoutbox_remove'], '" />
					</div>
					<strong>', $txt[139], ':</strong> ', $context['page_index'], '
				</td>
			</tr>
		</table>
		<input type="hidden" name="sc" value="', $context['session_id'], '" />
	</form>';
}

function template_shoutbox_edit()
{
	global $context, $settings, $options, $scripturl, $txt, $helptxt, $modSettings;

	echo '
<form action="', $scripturl, '?action=manageportal;area=portalshoutbox;sa=edit" method="post" accept-charset="', $context['character_set'], '">
	<div class="tborder" style="width: 85%; margin: 0 auto;">
		<table class="sp_table" cellpadding="4">
			<tr>
				<td colspan="3" class="sp_regular_padding catbg">', $context['page_title'], '</td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_name'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="name" value="', $context['SPortal']['shoutbox']['name'], '" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_permissions'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2">';

	sp_template_inline_permissions();

	echo '
				</td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_permissions_type'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2">
					<input class="check" type="radio" name="permission_type" value="0"', empty($context['SPortal']['shoutbox']['permission_type']) || $context['SPortal']['shoutbox']['permission_type'] > 2 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionOne'], '<br />
					<input class="check" type="radio" name="permission_type" value="1"', $context['SPortal']['shoutbox']['permission_type'] == 1 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionAll'], '<br />
					<input class="check" type="radio" name="permission_type" value="2"', $context['SPortal']['shoutbox']['permission_type'] == 2 ? ' checked="checked"' : '', ' />', $txt['sp-blocksPermissionIgnore'], '<br />
				</td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-shoutboxesWarning" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_warning'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="warning" value="', $context['SPortal']['shoutbox']['warning'], '" size="25" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16"><a href="', $scripturl, '?action=helpadmin;help=sp-shoutboxesBBC" onclick="return reqWin(this.href);" class="help"><img src="', $settings['images_url'], '/helptopics.gif" alt="', $txt[119], '" border="0" align="top" /></a></td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_bbc'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2">
					<select name="allowed_bbc[]" size="7" multiple="multiple">';

	foreach ($context['allowed_bbc'] as $tag => $label)
		if (!isset($context['disabled_tags'][$tag]))
			echo '
						<option value="', $tag, '"', in_array($tag, $context['SPortal']['shoutbox']['allowed_bbc']) ? ' selected="selected"' : '', '>[', $tag, '] - ', $label, '</option>';

	echo '
					</select>
				</td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_height'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="height" value="', $context['SPortal']['shoutbox']['height'], '" size="10" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_num_show'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="num_show" value="', $context['SPortal']['shoutbox']['num_show'], '" size="10" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_num_max'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="num_max" value="', $context['SPortal']['shoutbox']['num_max'], '" size="10" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_reverse'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="checkbox" name="reverse" value="1"', $context['SPortal']['shoutbox']['reverse'] ? ' checked="checked"' : '', ' class="check" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_caching'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="checkbox" name="caching" value="1"', $context['SPortal']['shoutbox']['caching'] ? ' checked="checked"' : '', ' class="check" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_refresh'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="text" name="refresh" value="', $context['SPortal']['shoutbox']['refresh'], '" size="10" /></td>
			</tr>
			<tr>
				<td class="windowbg2" valign="top" width="16">&nbsp;</td>
				<th class="sp_regular_padding sp_top sp_right windowbg2">', $txt['sp_admin_shoutbox_col_status'], ':</th>
				<td class="sp_regular_padding sp_top windowbg2"><input type="checkbox" name="status" value="1"', $context['SPortal']['shoutbox']['status'] ? ' checked="checked"' : '', ' class="check" /></td>
			</tr>
			<tr>
				<td colspan="3" class="sp_regular_padding sp_center windowbg2"><input type="submit" name="submit" value="', $context['page_title'], '" /></td>
			</tr>
		</table>
	</div>
	<input type="hidden" name="shoutbox_id" value="', $context['SPortal']['shoutbox']['id'], '" />
	<input type="hidden" name="sc" value="', $context['session_id'], '" />
</form>';
}

function template_shoutbox_block_redirect()
{
	global $context;

	echo '
	<table border="0" align="center" cellspacing="1" cellpadding="4" class="tborder" width="40%">
		<tr class="catbg">
			<td>', $context['page_title'], '</td>
		</tr>
		<tr class="windowbg2">
			<td align="center">
				', $context['redirect_message'], '
			</td>
		</tr>
	</table>';
}

?>