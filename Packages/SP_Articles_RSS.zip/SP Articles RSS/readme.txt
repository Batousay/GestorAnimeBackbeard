[hr]
[center][color=red][size=14pt][b]SP Articles RSS[/b][/size][/color]
[/center]
[hr]

[color=blue][b]Introduction[/b][/color]
This mod give RSS feature to SimplePortal Articles. Note: You [color=red]must have installed SimplePortal[/color] before you can use features from this mod. This mod has no settings and no need to be enable you can use it like typical SMF RSS. 

[b][color=blue]Usage[/color][/b]
http://yourforumdomain.com/index.php?action=.xml;sa=articles;type=rss;limit=4
[b]type[/b] = RSS type (can be rss, rss2, rdf or atom)
[b]limit[/b] = Number of articles


